#!/usr/bin/env python3
"""Self-contained original motion-graphics promo for Petersburg in Details.
No counterfeit app UI; factual statements are based on official project metadata.
"""
from pathlib import Path
import io, math, subprocess, wave, time, os, textwrap
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT=Path('/mnt/data/video_project');AS=ROOT/'assets';AS.mkdir(exist_ok=True)
W,H,FPS=720,1280,24
SCENE_DUR=[3.8,4.0,4.1,4.2,4.1,4.1,4.2,4.2,5.5]
TOTAL=sum(SCENE_DUR)
NAVY=(0,10,46); WHITE=(244,247,255); GOLD=(243,195,99); MUTED=(195,208,232); ICE=(168,232,252); BLUE=(85,177,246)
FONT_REG='/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf'
FONT_BOLD='/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf'
F={}
def ft(sz,b=False):
    key=(sz,b)
    if key not in F:F[key]=ImageFont.truetype(FONT_BOLD if b else FONT_REG,sz)
    return F[key]
def roundrect(d,xy,rad,fill,outline=None,width=2):d.rounded_rectangle(xy,radius=rad,fill=fill,outline=outline,width=width)
def block(d,x,y,lines,size=62,color=WHITE,bold=True,leading=1.15,anchor=None):
    yy=y
    for line in lines.split('\n'):
        d.text((x,yy),line,font=ft(size,bold),fill=color,anchor=anchor,stroke_width=0)
        yy+=int(size*leading)
    return yy

def soft_bg(seed):
    # Navy-gradient plus brand blue bloom; no external imagery.
    yy,xx=np.mgrid[0:H,0:W]; f=yy/(H-1)
    base=np.stack([np.full_like(f,0,dtype=float)+1,9+13*f,38+52*f],axis=-1)
    cx=550-80*math.sin(seed*1.3);cy=400+90*math.cos(seed*1.9)
    z=np.exp(-(((xx-cx)/550)**2+((yy-cy)/570)**2)*1.5)
    base+=np.stack([3*z,27*z,80*z],axis=-1)
    noise=(np.sin(xx*0.018+seed)*np.cos(yy*0.015))*0.8
    base+=noise[...,None]
    im=Image.fromarray(np.uint8(np.clip(base,0,255)),'RGB')
    d=ImageDraw.Draw(im,'RGBA')
    # Horizontal skyline/grid linework (decorative, not maps or app screenshots).
    for i in range(-4,10):
        x=54+i*102
        d.line([(x,475),(x-110,1170)],fill=(99,187,250,16),width=2)
    for j in range(9):
        y=515+j*85
        d.line([(0,y),(W,y-80)],fill=(93,175,247,13),width=1)
    d.ellipse((360,490,1130,1220),outline=(168,232,252,24),width=2)
    d.ellipse((495,630,990,1125),outline=(168,232,252,16),width=2)
    return im

icon=Image.open(AS/'icon.png').convert('RGB')
qr=Image.open(AS/'qr_release.png').convert('RGB')
def icon_paste(im,xy,size,radius=26):
    s=icon.resize((size,size),Image.Resampling.LANCZOS)
    mask=Image.new('L',(size,size));ImageDraw.Draw(mask).rounded_rectangle((0,0,size-1,size-1),radius=radius,fill=255)
    im.paste(s,xy,mask)

def draw_top(im,n):
    d=ImageDraw.Draw(im,'RGBA')
    icon_paste(im,(54,65),58,14)
    d.text((127,75),'ПЕТЕРБУРГ В ДЕТАЛЯХ',font=ft(23,True),fill=WHITE)
    roundrect(d,(565,74,667,112),19,(3,35,94,210),outline=(168,232,252,90),width=1)
    d.text((582,82),'v1.1.1',font=ft(18,True),fill=ICE)
    d.line((54,136,667,136),fill=(168,232,252,42),width=1)

def foot(im,n,extra=None):
    d=ImageDraw.Draw(im,'RGBA')
    d.line((54,1168,666,1168),fill=(168,232,252,70),width=1)
    d.text((54,1190),'ОФИЦИАЛЬНОЕ ПРИЛОЖЕНИЕ • ANDROID',font=ft(17,True),fill=MUTED)
    d.text((54,1228),'Авторская графика — не экран приложения',font=ft(16),fill=(175,195,215,192))
    d.text((635,1193),f'{n+1:02}',font=ft(18,True),fill=GOLD)

def label(d,s,y=178):d.text((56,y),s,font=ft(24,True),fill=GOLD)

def card(d,xy,fill=(1,26,76,228),outline=(104,188,244,84),radius=30):roundrect(d,xy,radius,fill,outline,2)

def skyline(d,ybase=1020,color=(159,209,239,74)):
    # A generic Petersburg-inspired skyline illustration, not copyrighted map tiles.
    d.line([(20,ybase),(705,ybase)],fill=color,width=3)
    for x,width,height in [(50,105,130),(176,95,165),(300,120,220),(462,145,145),(624,65,100)]:
        d.rectangle((x,ybase-height,x+width,ybase),outline=color,width=3)
        for wx in range(x+18,x+width-8,29):
            for wy in range(ybase-height+30,ybase-24,38):
                d.rounded_rectangle((wx,wy,wx+8,wy+17),radius=4,fill=(93,163,220,36))
    d.arc((352,ybase-338,465,ybase-190),180,360,fill=color,width=4)
    d.line([(410,ybase-334),(410,ybase-423)],fill=color,width=4)
    d.polygon([(409,ybase-453),(398,ybase-421),(421,ybase-421)],fill=GOLD)
    # Bridge outline
    d.arc((72,ybase-18,648,ybase+156),180,360,fill=(243,195,99,175),width=5)

def build_scene(i):
    im=soft_bg(i);d=ImageDraw.Draw(im,'RGBA');draw_top(im,i);label(d,['ОТКРОЙТЕ ГОРОД ЗАНОВО','ГОРОДСКОЙ КАТАЛОГ','SMART WALK','ПЕШЕХОДНАЯ НАВИГАЦИЯ','КРАСИВЫЕ МАРШРУТЫ','ЗНАНИЯ О ГОРОДЕ','ДЕТАЛИ ПРОГУЛКИ','УДОБНО И БЕЗ АККАУНТА','СКАЧАТЬ ПРИЛОЖЕНИЕ'][i]);
    if i==0:
        block(d,57,228,'Петербург\nв деталях',76,WHITE,True,1.18)
        block(d,59,426,'Замечай больше.\nОткрывай Петербург.',34,ICE,True,1.25)
        # Hero brand icon with golden orbit rings
        d.ellipse((155,593,566,1004),outline=(243,195,99,60),width=3)
        d.ellipse((194,635,526,967),outline=(168,232,252,70),width=4)
        roundrect(d,(220,664,500,943),62,(0,11,42,255),(243,195,99,120),3)
        icon_paste(im,(235,680),250,53)
        skyline(d,1121,(139,208,255,30))
    elif i==1:
        block(d,56,223,'180 мест',92,WHITE,True,1.12)
        block(d,58,340,'для знакомства\nс Петербургом',46,ICE,True,1.18)
        block(d,58,485,'Известные достопримечательности\nи необычные уголки города.',28,MUTED,False,1.27)
        for j,(a,b) in enumerate([('НАБЕРЕЖНЫЕ','Прогулки у воды'),('ПЛОЩАДИ','Пространства города'),('НЕОБЫЧНОЕ','Места с историей')]):
            top=638+j*139;card(d,(57,top,664,top+115))
            d.ellipse((83,top+28,142,top+87),fill=(243,195,99,35),outline=(243,195,99,140),width=2)
            d.text((102,top+39),f'0{j+1}',font=ft(24,True),fill=GOLD)
            d.text((168,top+22),a,font=ft(27,True),fill=WHITE)
            d.text((168,top+62),b,font=ft(23),fill=MUTED)
    elif i==2:
        block(d,56,225,'Прогулка\nпод ваш интерес',62,WHITE,True,1.18)
        block(d,58,408,'Выберите темы и время.\nSmart Walk предложит места.',29,MUTED,False,1.27)
        card(d,(57,570,664,1045),(0,26,80,228))
        d.text((95,602),'ВАШ ПЛАН',font=ft(25,True),fill=ICE)
        labels=[('ИНТЕРЕСЫ','История • архитектура'),('ВРЕМЯ','По вашему бюджету'),('МЕСТА','Обычные и необычные')]
        for j,(key,val) in enumerate(labels):
            y=674+j*109
            roundrect(d,(85,y,635,y+91),20,(18,65,122,200),(102,192,242,55),1)
            d.text((108,y+11),key,font=ft(19,True),fill=GOLD)
            d.text((108,y+44),val,font=ft(25),fill=WHITE)
        d.text((105,1010),'Далее маршрут строит Yandex MapKit',font=ft(18),fill=ICE)
    elif i==3:
        block(d,56,225,'Идите пешком\nс подсказками',64,WHITE,True,1.15)
        block(d,58,414,'Расстояние, время и повороты —\nна основе Yandex MapKit.',28,MUTED,False,1.27)
        card(d,(57,577,663,1047),(0,30,84,222))
        # Map-like schematic, not real navigation UI
        for k in range(5):
            x=94+k*115
            d.line([(x,606),(x-25,1004)],fill=(127,198,245,60),width=9)
        for k in range(5):
            y=632+k*85
            d.line([(91,y),(634,y+20)],fill=(127,198,245,40),width=10)
        pts=[(113,952),(192,862),(350,865),(415,756),(579,721)]
        d.line(pts,fill=(85,177,246,70),width=25,joint='curve')
        d.line(pts,fill=(168,232,252,190),width=9,joint='curve')
        for x,y in [pts[0],pts[-1]]:
            d.ellipse((x-19,y-19,x+19,y+19),fill=(243,195,99,235))
        d.text((90,996),'СХЕМА МАРШРУТА · НЕ ЭКРАН MAPKIT',font=ft(17,True),fill=MUTED)
    elif i==4:
        block(d,56,223,'По дороге —\nещё больше города',61,WHITE,True,1.18)
        block(d,58,409,'Набережные, пешеходные улицы\nи площади — часть идеи прогулки.',29,MUTED,False,1.27)
        # illustrated river embankment, not a photograph
        roundrect(d,(57,562,663,1052),28,(0,26,81,195),(168,232,252,54),2)
        d.polygon([(64,912),(659,780),(659,1042),(64,1042)],fill=(20,107,168,116))
        for q in range(7):
            y=951+q*12
            d.arc((79,y,660,y+58),200,340,fill=(168,232,252,35),width=3)
        # arched bridge
        d.line((78,786,638,770),fill=(243,195,99,210),width=9)
        for x in [112,214,315,416,516,610]:
            d.line((x,785,x,835),fill=(243,195,99,150),width=3)
        d.arc((78,786,314,966),180,360,fill=(243,195,99,220),width=7)
        d.arc((313,785,552,964),180,360,fill=(243,195,99,220),width=7)
        # abstract palaces
        for x,ww,hh in [(105,86,139),(204,112,180),(457,141,199)]:
            d.rectangle((x,784-hh,x+ww,781),fill=(71,120,181,110),outline=(195,208,232,130),width=3)
            d.polygon([(x-8,784-hh),(x+ww/2,759-hh),(x+ww+8,784-hh)],fill=(243,195,99,107))
    elif i==5:
        block(d,56,224,'35 исторических\nсправок',69,WHITE,True,1.14)
        block(d,58,421,'Путешествие с контекстом:\nузнавайте историю мест.',29,MUTED,False,1.26)
        card(d,(57,583,665,1050),(0,29,83,237))
        # Stylized book and Petersburg motifs
        d.rounded_rectangle((108,661,362,963),radius=17,fill=(29,69,130,240),outline=(243,195,99,145),width=3)
        d.rounded_rectangle((350,661,612,963),radius=17,fill=(15,50,116,235),outline=(243,195,99,145),width=3)
        d.line((350,674,350,954),fill=(243,195,99,196),width=3)
        for col in [135,390]:
            for j in range(5):
                y=750+j*35;d.line((col,y,col+178,y),fill=(195,208,232,95),width=3)
        d.arc((177,710,289,830),185,355,fill=(243,195,99,235),width=6)
        d.ellipse((202,698,254,746),outline=(243,195,99,175),width=3)
        d.text((138,995),'РЕДАКЦИОННЫЕ МАТЕРИАЛЫ ПРОЕКТА',font=ft(17,True),fill=ICE)
    elif i==6:
        block(d,56,225,'Детали\nвашей прогулки',67,WHITE,True,1.16)
        block(d,58,410,'Четыре дополнительные оценки\nдля существующего маршрута.',29,MUTED,False,1.24)
        items=[('ТЕНЬ','Shade'),('ТИШИНА','Quiet'),('ПОВЕРХНОСТЬ','Puddle'),('ПЫЛЬЦА','Pollen')]
        for j,(n,v) in enumerate(items):
            x=57+(j%2)*311;y=598+(j//2)*185
            card(d,(x,y,x+289,y+159),(0,30,80,230))
            d.ellipse((x+25,y+23,x+78,y+76),fill=(243,195,99,38),outline=(243,195,99,146),width=2)
            d.text((x+36,y+33),f'{j+1:02d}',font=ft(23,True),fill=GOLD)
            d.text((x+23,y+92),n,font=ft(22,True),fill=WHITE)
            d.text((x+23,y+125),v,font=ft(18),fill=ICE)
        roundrect(d,(57,1005,664,1087),20,(243,195,99,19),(243,195,99,95),1)
        d.text((78,1023),'Это расчётные модели, а не измерения.',font=ft(23,True),fill=GOLD)
    elif i==7:
        block(d,56,225,'Без аккаунта.\nБлиже к городу.',63,WHITE,True,1.16)
        block(d,58,406,'Избранное и настройки\nсохраняются на вашем устройстве.',29,MUTED,False,1.28)
        entries=[('01','Избранные места','Сохраните, чтобы вернуться'),('02','Голосовой поиск','При поддержке устройства'),('03','ИИ-помощник','После согласия, при доступности')]
        for j,(num,title,txt) in enumerate(entries):
            y=601+j*151;card(d,(57,y,663,y+125))
            d.text((83,y+26),num,font=ft(31,True),fill=GOLD)
            d.text((158,y+19),title,font=ft(30,True),fill=WHITE)
            d.text((158,y+66),txt,font=ft(21),fill=MUTED)
    else:
        block(d,55,227,'Откройте\nПетербург',69,WHITE,True,1.14)
        d.text((59,411),'Скачайте официальную версию 1.1.1',font=ft(27),fill=ICE)
        roundrect(d,(159,536,563,1012),40,(249,250,252,255),(243,195,99,255),3)
        qim=qr.resize((326,326),Image.Resampling.NEAREST)
        im.paste(qim,(197,588));d=ImageDraw.Draw(im,'RGBA')
        d.text((218,923),'СКАНИРУЙТЕ QR-КОД',font=ft(23,True),fill=(0,25,65))
        d.text((197,976),'GitHub Releases · Android 8.0+',font=ft(17,True),fill=(2,46,109))
        block(d,75,1052,'Замечай больше. Открывай Петербург.',26,GOLD,True,1.17)
    foot(im,i)
    return np.ascontiguousarray(np.array(im),dtype=np.uint8)

# Original synthesized soft soundtrack; no samples, no third-party copyrighted music.
def generate_music(seconds=TOTAL):
    sr=32000;n=int(seconds*sr);t=np.arange(n,dtype=np.float32)/sr
    audio=np.zeros(n,dtype=np.float32)
    notes=[(130.813,[0,3,7]),(103.826,[0,4,7]),(155.563,[0,4,7]),(116.541,[0,4,7])]
    bar=3.6
    for ib in range(int(math.ceil(seconds/bar))):
        start=ib*bar;a=int(start*sr);b=min(n,int((start+bar)*sr));dt=t[a:b]-start
        root,ints=notes[ib%4]
        for iv in ints:
            f=root*2**(iv/12)
            s=.5*np.sin(2*np.pi*f*dt)+.18*np.sin(2*np.pi*f*2*dt)+.08*np.sin(2*np.pi*f*3*dt)
            env=np.minimum(1,dt/0.52)*np.minimum(1,np.maximum(0,(bar-dt)/0.65))
            audio[a:b]+=0.05*s*env
        bass=root/2
        audio[a:b]+=0.045*np.sin(2*np.pi*bass*dt)*(np.minimum(1,dt/.13)*np.minimum(1,np.maximum(0,(bar-dt)/.4)))
    # crystalline plucks, short melody in C minor pentatonic
    melody=[392,466.16,523.25,466.16,392,349.23,311.13,349.23,392,466.16,622.25,523.25,466.16,392,349.23,311.13]
    step=.91
    for ix in range(int(seconds/step)+1):
        at=ix*step;a=int(at*sr);b=min(n,a+int(.74*sr));
        if a>=n:break
        dt=np.arange(b-a,dtype=np.float32)/sr
        hz=melody[ix%len(melody)]
        env=np.exp(-4.0*dt)*(1-np.exp(-55*dt))
        audio[a:b]+=0.05*env*(np.sin(2*np.pi*hz*dt)+.15*np.sin(2*np.pi*hz*2.01*dt))
    # subdued original percussive ticks
    rng=np.random.default_rng(20261026)
    for at in np.arange(0,seconds,0.455):
        a=int(at*sr);b=min(n,a+1400)
        if a>=n:break
        tt=np.arange(b-a,dtype=np.float32)/sr
        audio[a:b]+=.012*rng.standard_normal(b-a).astype(np.float32)*np.exp(-70*tt)
    audio*=np.minimum(1,t/1.3)*np.minimum(1,np.maximum(0,seconds-t)/1.6)
    audio=np.tanh(audio*1.25)
    pcm=(np.clip(audio,-1,1)*32767).astype(np.int16)
    out=ROOT/'original_audio.wav'
    with wave.open(str(out),'wb') as wavefile:
        wavefile.setnchannels(1);wavefile.setsampwidth(2);wavefile.setframerate(sr);wavefile.writeframes(pcm.tobytes())
    print('ORIGINAL AUDIO',out,'duration',seconds,flush=True)
    return out

def dynamic_frame(base,scene,at,t):
    # restrained motion: slight camera drift + glints; preserve readability
    fr=base.copy()
    # Sparse moving stars/glints on linework, no fake UI.
    for k in range(7):
        x=int(55+((k*107+int(t*9)*(k%2+1))%600))
        y=int(550+((k*141+int(t*13))%575))
        cv2.circle(fr,(x,y),1+(k%3==0),(200,225,255),-1,lineType=cv2.LINE_AA)
    if scene in [3,4]:
        # route marker moves on original schematic path as active visual cue
        if scene==3:
            pts=np.array([(113,952),(192,862),(350,865),(415,756),(579,721)],np.float32)
        else:pts=np.array([(103,852),(215,803),(337,819),(486,763),(622,779)],np.float32)
        lengths=np.linalg.norm(np.diff(pts,axis=0),axis=1); arclength=np.concatenate([[0],np.cumsum(lengths)]); total=arclength[-1]
        dist=(at/SCENE_DUR[scene])*total;seg=np.searchsorted(arclength,dist,side='right')-1;seg=int(np.clip(seg,0,len(pts)-2))
        pct=(dist-arclength[seg])/(arclength[seg+1]-arclength[seg]);pos=pts[seg]*(1-pct)+pts[seg+1]*pct
        x,y=int(pos[0]),int(pos[1]);
        cv2.circle(fr,(x,y),25,(103,187,250),2,lineType=cv2.LINE_AA)
        cv2.circle(fr,(x,y),13,(99,195,243),-1,lineType=cv2.LINE_AA)
        cv2.circle(fr,(x,y),6,(255,247,229),-1,lineType=cv2.LINE_AA)
    if scene==0:
        x=int(359+5*math.sin(at*2.5));y=int(802+4*math.cos(at*2))
        cv2.circle(fr,(x,y),181+int(5*math.sin(at*2)),(111,193,248),2,lineType=cv2.LINE_AA)
    # Progress bar, fixed to brand UI of video itself, not app.
    progress=max(0,min(1,t/TOTAL))
    cv2.rectangle(fr,(0,H-7),(W,H),(19,33,76),-1)
    cv2.rectangle(fr,(0,H-7),(int(W*progress),H),(99,195,243),-1)
    return fr

def run():
    t0=time.time()
    scenes=[build_scene(i) for i in range(len(SCENE_DUR))]
    for j,s in enumerate(scenes):Image.fromarray(s).save(ROOT/f'frame_{j:02}.png',optimize=True)
    cols=3; rows=3;small=(240,427)
    contact=Image.new('RGB',(cols*small[0],rows*small[1]))
    for j,arr in enumerate(scenes):
        im=Image.fromarray(arr).resize(small,Image.Resampling.LANCZOS)
        contact.paste(im,((j%cols)*small[0],(j//cols)*small[1]))
    contact.save('/mnt/data/SPb_in_Details_Promo_Storyboard_Preview.png')
    music=generate_music()
    out='/mnt/data/SPb_in_Details_Marketing_Video_v1.0_vertical.mp4'
    frames=round(TOTAL*FPS)
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24',
         '-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-i',str(music),
         '-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','veryfast','-crf','22','-pix_fmt','yuv420p',
         '-c:a','aac','-b:a','112k','-movflags','+faststart','-shortest',out]
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
    cumulative=np.cumsum([0]+SCENE_DUR)
    alpha=0.28 # timing crossfade duration
    try:
        for fi in range(frames):
            now=fi/FPS
            scene=int(np.searchsorted(cumulative,now,side='right')-1)
            scene=min(scene,len(scenes)-1)
            rel=now-cumulative[scene]
            a=dynamic_frame(scenes[scene],scene,rel,now)
            # Transition before each scene boundary, ~0.28 s
            rem=cumulative[scene+1]-now
            if scene<len(scenes)-1 and rem<alpha:
                b=dynamic_frame(scenes[scene+1],scene+1,0,now)
                wt=float(np.clip((alpha-rem)/alpha,0,1))
                a=cv2.addWeighted(a,1-wt,b,wt,0)
            p.stdin.write(a.tobytes())
            if fi%120==0:print('VIDEO FRAME',fi,'/',frames, 'elapsed',round(time.time()-t0,1),flush=True)
        p.stdin.close()
        result=p.wait(timeout=100)
        if result!=0:raise RuntimeError('ffmpeg status '+str(result)+' stderr '+p.stderr.read().decode()[-1400:])
    except Exception:
        try:p.stdin.close()
        except:pass
        p.kill();raise
    print('DONE',out,os.stat(out).st_size,'seconds',round(time.time()-t0,1),flush=True)

if __name__=='__main__':run()
