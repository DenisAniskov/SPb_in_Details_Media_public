#!/usr/bin/env python3
"""Landscape 16:9 motion graphic for «Петербург в деталях». No counterfeit UI."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import math,cv2,numpy as np,subprocess,os,time,json
R=Path(__file__).resolve().parent; AS=R/'assets'
W,H,FPS=1920,1080,24
DUR=[3.8,4.0,4.1,4.2,4.1,4.1,4.2,4.2,5.5]; TOTAL=sum(DUR)
NAVY=(1,9,42); WHITE=(242,247,255); ICE=(170,231,250); GOLD=(243,195,99); MUTED=(194,209,229); BLUE=(78,171,244)
BR='/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf'; RG='/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf'; fonts={}
icon=Image.open(AS/'icon.png').convert('RGB'); qr=Image.open(AS/'qr_release.png').convert('RGB')
def ft(s,b=False):
 k=(s,b)
 if k not in fonts: fonts[k]=ImageFont.truetype(BR if b else RG,s)
 return fonts[k]
def line(d,x,y,t,size=40,fill=WHITE,b=False): d.text((x,y),t,font=ft(size,b),fill=fill)
def ls(d,x,y,t,size=42,fill=WHITE,b=False,leading=1.26):
 for p in t.split('\n'):line(d,x,y,p,size,fill,b);y+=int(size*leading)
 return y

def rr(d,rect,r=25,fill=(5,33,85,233),outline=(96,175,244,102),sw=2):d.rounded_rectangle(rect,radius=r,fill=fill,outline=outline,width=sw)
def circle(d,center,r,fill,stroke=None,sw=2):
 x,y=center;d.ellipse((x-r,y-r,x+r,y+r),fill=fill,outline=stroke,width=sw)
def icon_at(im,x,y,s):
 ico=icon.resize((s,s),Image.Resampling.LANCZOS)
 mask=Image.new('L',(s,s));ImageDraw.Draw(mask).rounded_rectangle((0,0,s-1,s-1),radius=int(s*.21),fill=255)
 im.paste(ico,(x,y),mask)

def bg(scene):
 # smooth exact-resolution gradient; no resizing of text or original icon.
 yy=np.linspace(0,1,H,dtype=np.float32)[:,None,None]
 a=np.array([1.,10.,46.],dtype=np.float32)[None,None,:]
 b=np.array([3.,19.,70.],dtype=np.float32)[None,None,:]
 pix=np.broadcast_to(a*(1-yy)+b*yy,(H,W,3)).copy()
 yy2,xx=np.ogrid[:H,:W]
 cx=1530+70*math.sin(scene*.8);cy=440+50*math.cos(scene)
 gl=np.exp(-((xx-cx)**2/(820**2)+(yy2-cy)**2/(540**2))*1.6).astype(np.float32)
 pix+=gl[:,:,None]*np.array([3,29,69],np.float32)[None,None,:]
 im=Image.fromarray(np.clip(pix,0,255).astype(np.uint8),'RGB'); d=ImageDraw.Draw(im,'RGBA')
 for j in range(11):
  x=1005+j*97;d.line((x,155,x-250,1020),fill=(140,207,246,18),width=2)
 for j in range(7):
  y=230+j*115;d.line((950,y,1910,y-38),fill=(140,207,246,16),width=2)
 d.ellipse((1110,95,2030,1015),outline=(134,220,253,23),width=3)
 d.ellipse((1300,270,1910,880),outline=(134,220,253,20),width=3)
 return im

def base(scene,cat):
 im=bg(scene); d=ImageDraw.Draw(im,'RGBA')
 icon_at(im,104,67,82);d=ImageDraw.Draw(im,'RGBA')
 line(d,207,80,'ПЕТЕРБУРГ В ДЕТАЛЯХ',32,WHITE,True)
 rr(d,(1550,79,1810,132),23,(4,43,98,225),(168,232,252,80),2)
 line(d,1604,89,'ANDROID  ·  1.1.1',23,ICE,True)
 d.line((104,158,1810,158),fill=(160,215,247,61),width=2)
 rr(d,(105,203,640,265),29,(19,60,106,195),(210,179,103,108),2)
 line(d,133,215,cat,24,GOLD,True)
 d.line((105,982,1810,982),fill=(158,220,246,55),width=2)
 line(d,107,1002,'Замечай больше. Открывай Петербург.',23,MUTED)
 line(d,1450,1002,'spb-in-details.vercel.app',20,ICE)
 return im,d

def main_title(d,a,b,sub,size=83):
 ls(d,108,300,a,size,WHITE,True,1.13)
 line(d,108,476,b,42,GOLD,True)
 ls(d,110,557,sub,33,MUTED,False,1.37)

def right_container(d,label=None):
 rr(d,(1080,235,1810,900),45,(2,34,87,223),(134,201,245,106),3)
 if label:line(d,1143,282,label,27,ICE,True)

def footer_sub(d,txt):
 line(d,112,895,txt,25,ICE)

def skyline(d):
 # vector-only stylized city; explicitly not a real map
 water=(26,104,164,190)
 d.polygon([(1098,772),(1797,752),(1805,888),(1099,890)],fill=water)
 for i in range(5):
  y=797+i*18;d.arc((1134,y,1823,y+110),200,345,fill=(130,210,250,55),width=4)
 for x,w,h in [(1153,115,203),(1296,140,271),(1470,104,323),(1605,147,226)]:
  y=750-h;d.rectangle((x,y,x+w,746),fill=(12,55,124,220),outline=(142,202,237,150),width=3)
  for yy in range(y+46,718,51):
   for xx in range(x+26,x+w-10,44):d.rectangle((xx,yy,xx+12,yy+25),fill=(243,195,99,145))
 d.polygon([(1518,326),(1498,419),(1538,419)],fill=(243,195,99,245));d.line((1518,328,1518,298),fill=(243,195,99,250),width=4)
 d.line((1137,765,1785,765),fill=(243,195,99,222),width=7)
 d.arc((1137,765,1471,978),180,360,fill=(243,195,99,212),width=9)
 d.arc((1470,765,1784,978),180,360,fill=(243,195,99,212),width=9)

def scene(i):
 cats=['ИСТОРИЯ ГОРОДА','КАТАЛОГ МЕСТ','ПЛАНИРОВАНИЕ','МАРШРУТЫ И НАВИГАЦИЯ','ПЕТЕРБУРГ ПО ДОРОГЕ','ИСТОРИЯ И КОНТЕКСТ','ДОПОЛНИТЕЛЬНЫЕ ОЦЕНКИ','ПРИВАТНОСТЬ','СКАЧАТЬ ПРИЛОЖЕНИЕ']
 im,d=base(i,cats[i])
 if i==0:
  main_title(d,'Петербург\nв деталях','ГОРОД, КОТОРЫЙ СТОИТ ЗАМЕЧАТЬ','Пешеходный навигатор\nдля знакомства с Санкт-Петербургом.',83)
  skyline(d);icon_at(im,1392,303,190);d=ImageDraw.Draw(im,'RGBA')
  footer_sub(d,'180 мест  •  пешеходные маршруты  •  Android')
 elif i==1:
  main_title(d,'180 мест','ИЗВЕСТНОЕ И НЕОЧЕВИДНОЕ','Открывайте достопримечательности,\nнабережные и необычные места.',96)
  right_container(d,'ЧТО МОЖНО НАЙТИ')
  for j,(title,sub) in enumerate([('01  НАБЕРЕЖНЫЕ','Прогулки у воды'),('02  ПЛОЩАДИ','Городские пространства'),('03  НЕОБЫЧНЫЕ МЕСТА','Откройте новое')]):
   y=348+j*157;rr(d,(1144,y,1745,y+123),23,(17,64,119,213),(153,218,249,49));line(d,1172,y+19,title,30,WHITE,True);line(d,1173,y+69,sub,25,MUTED)
  footer_sub(d,'Редакционный каталог, не полный перечень объектов города.')
 elif i==2:
  main_title(d,'Smart Walk','ПРОГУЛКА ПОД ВАШ ИНТЕРЕС','Выберите, что интересно,\nи сколько времени есть.',87)
  right_container(d,'СЦЕНАРИЙ ПРОГУЛКИ')
  for j,(n,title,txt) in enumerate([('01','Выбрать интересы','Архитектура, история, необычное'),('02','Указать время','Задайте комфортный бюджет'),('03','Получить предложение','Последовательность мест в каталоге')]):
   y=341+j*156;rr(d,(1141,y,1749,y+124),25,(15,65,127,209),(152,212,248,65));circle(d,(1196,y+61),31,(243,195,99,48),(243,195,99,181));line(d,1175,y+42,n,23,GOLD,True);line(d,1253,y+16,title,30,WHITE,True);line(d,1253,y+67,txt,22,MUTED)
  footer_sub(d,'После подбора пешеходный маршрут строит Yandex MapKit.')
 elif i==3:
  main_title(d,'Идите пешком','МАРШРУТ С ПОДСКАЗКАМИ','Расстояние, время и повороты\nрассчитывает Yandex MapKit.',85)
  right_container(d,'СХЕМА ПЕШЕХОДНОГО МАРШРУТА')
  for j in range(7):
   x=1150+j*90;d.line((x,347,x-135,849),fill=(121,194,242,48),width=13)
  for j in range(7):
   y=375+j*78;d.line((1131,y,1757,y-34),fill=(121,194,242,55),width=13)
  pts=[(1198,793),(1271,726),(1370,725),(1440,631),(1599,625),(1680,480)]
  d.line(pts,fill=(22,72,139,255),width=31,joint='curve');d.line(pts,fill=ICE,width=12,joint='curve')
  circle(d,pts[0],24,GOLD);circle(d,pts[-1],24,GOLD);line(d,1166,828,'СТАРТ',22,WHITE,True);line(d,1667,506,'ЦЕЛЬ',22,WHITE,True)
  line(d,1146,866,'Иллюстрация, не экран приложения',19,MUTED)
  footer_sub(d,'Отклонение определяется; перестроение — вручную.')
 elif i==4:
  main_title(d,'Красивые улицы','ИЗВЕСТНЫЕ И ТИХИЕ МАРШРУТЫ','Набережные, пешеходные улицы\nи площади — часть прогулки.',79)
  right_container(d,'ГОРОДСКИЕ ПРОСТРАНСТВА');skyline(d)
  footer_sub(d,'Схематичная иллюстрация, не фотография города.')
 elif i==5:
  main_title(d,'35 исторических','СПРАВОК О МЕСТАХ','Узнавайте о прошлом города\nво время прогулки.',81)
  right_container(d,'РЕДАКЦИОННЫЙ КОНТЕНТ')
  d.rounded_rectangle((1163,366,1450,748),radius=22,fill=(32,79,143,230),outline=(243,195,99,194),width=4)
  d.rounded_rectangle((1450,366,1738,748),radius=22,fill=(20,66,132,222),outline=(243,195,99,194),width=4)
  d.line((1450,379,1450,737),fill=GOLD,width=4)
  for j in range(5):
   y=463+j*45;d.line((1200,y,1410,y),fill=(195,218,238,120),width=4);d.line((1485,y,1696,y),fill=(195,218,238,120),width=4)
  d.arc((1227,406,1355,544),185,350,fill=GOLD,width=8)
  line(d,1195,819,'Факты каталога и исторический контекст',25,MUTED)
  footer_sub(d,'Исторические справки — для отдельных записей каталога.')
 elif i==6:
  main_title(d,'Детали прогулки','НЕ ТОЛЬКО РАССТОЯНИЕ','Дополнительные расчётные оценки\nучастков существующего маршрута.',74)
  right_container(d,'ЧЕТЫРЕ МОДЕЛИ')
  for j,(a,b) in enumerate([('ТЕНЬ','Shade'),('ТИШИНА','Quiet'),('ПОВЕРХНОСТЬ','Puddle'),('ПЫЛЬЦА','Pollen')]):
   x=1141+(j%2)*304;y=355+(j//2)*200
   rr(d,(x,y,x+278,y+174),24,(18,70,127,226),(112,200,242,91))
   circle(d,(x+50,y+55),27,(243,195,99,54),(243,195,99,169))
   line(d,x+36,y+39,str(j+1).zfill(2),23,GOLD,True);line(d,x+23,y+93,a,26,WHITE,True);line(d,x+23,y+135,b,23,ICE)
  rr(d,(1141,779,1745,858),23,(243,195,99,31),(243,195,99,132));line(d,1165,798,'Модели, а не измерения на месте',22,GOLD,True)
  footer_sub(d,'Точные условия зависят от доступности источников данных.')
 elif i==7:
  main_title(d,'Без регистрации','ГОРОД, А НЕ АНКЕТА','Избранное и настройки остаются\nна вашем устройстве.',81)
  right_container(d,'ДОПОЛНИТЕЛЬНЫЕ ВОЗМОЖНОСТИ')
  for j,(title,sub) in enumerate([('ИЗБРАННОЕ','Сохраняйте понравившиеся места'),('ГОЛОС','Распознавание и озвучивание Android'),('ИИ-ПОМОЩНИК','Только после отдельного согласия')]):
   y=345+j*164;rr(d,(1144,y,1745,y+135),23,(13,59,112,218),(142,209,246,68));line(d,1182,y+21,title,30,WHITE,True);line(d,1182,y+76,sub,21,MUTED)
  footer_sub(d,'Карта, каталог и навигация не требуют ИИ-помощника.')
 else:
  ls(d,109,299,'Откройте\nПетербург',97,WHITE,True,1.12)
  line(d,110,563,'Скачайте официальную версию 1.1.1',36,GOLD,True)
  line(d,112,644,'Android 8.0+  ·  GitHub Releases',29,ICE)
  line(d,110,731,'Сайт: spb-in-details.vercel.app',28,MUTED)
  rr(d,(1218,238,1777,891),40,(249,250,254,255),(243,195,99,255),4)
  q=qr.resize((472,472),Image.Resampling.NEAREST);im.paste(q,(1262,281));d=ImageDraw.Draw(im,'RGBA')
  line(d,1300,772,'СКАНИРУЙТЕ QR-КОД',28,(1,35,74),True)
  line(d,1350,816,'Релиз v1.1.1',25,(10,62,119),True)
  footer_sub(d,'QR-код ведёт на официальный релиз приложения.')
 return np.array(im,dtype=np.uint8)

def build():
 tic=time.time();scenes=[]
 for i in range(9):
  frame=scene(i);scenes.append(frame); Image.fromarray(frame).save(R/f'landscape_scene_{i+1:02d}.png',optimize=True)
  print('SCENE',i,'built',round(time.time()-tic,1),'s',flush=True)
 contact=Image.new('RGB',(3*640,3*360))
 for j,s in enumerate(scenes):contact.paste(Image.fromarray(s).resize((640,360),Image.Resampling.LANCZOS),((j%3)*640,(j//3)*360))
 contact.save(R/'SPb_in_Details_Horizontal_Storyboard_v1.0.jpg',quality=88)
 # Frame-streaming keeps all labels in crisp original-resolution raster frames, no video upscaling.
 out=str(R/'SPb_in_Details_Marketing_Video_v1.0_horizontal.mp4')
 audio=str(R/'original_audio.wav')
 cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-i',audio,'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-threads','4','-c:a','aac','-b:a','144k','-movflags','+faststart','-shortest',out]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
 edges=np.cumsum([0]+DUR);frames=int(round(TOTAL*FPS)); fade=0.42
 try:
  for fi in range(frames):
   t=fi/FPS;i=int(np.searchsorted(edges,t,side='right')-1);i=min(8,i);rel=t-edges[i]
   a=scenes[i].copy()
   # slow, accurate decorative pulse. Never move or resample type or QR.
   k=(fi%FPS==0)
   if i==3:
    pts=np.array([(1198,793),(1271,726),(1370,725),(1440,631),(1599,625),(1680,480)],np.float32)
    seg=np.linalg.norm(np.diff(pts,axis=0),axis=1);cum=np.concatenate([[0],np.cumsum(seg)])
    dis=np.clip(rel/DUR[i],0,1)*cum[-1];j=int(np.clip(np.searchsorted(cum,dis,side='right')-1,0,len(seg)-1));frac=(dis-cum[j])/seg[j]
    p=pts[j]+frac*(pts[j+1]-pts[j]); xy=tuple(p.astype(int))
    cv2.circle(a,xy,27,(238,211,137),4,cv2.LINE_AA);cv2.circle(a,xy,15,(255,226,141),-1,cv2.LINE_AA)
    cv2.circle(a,xy,6,(255,255,255),-1,cv2.LINE_AA)
   if i==0:
    rad=139+int(5*math.sin(rel*1.9))
    cv2.circle(a,(1487,399),rad,(113,183,242),2,cv2.LINE_AA)
   # top thin read-through video progress indicator
   totalprog=t/TOTAL
   cv2.rectangle(a,(0,H-5),(W,H),(18,36,74),-1)
   cv2.rectangle(a,(0,H-5),(round(W*totalprog),H),(134,213,251),-1)
   rem=edges[i+1]-t
   if i<8 and rem<fade:
    b=scenes[i+1]
    mix=float(np.clip((fade-rem)/fade,0,1));mix=mix*mix*(3-2*mix)
    a=cv2.addWeighted(a,1-mix,b,mix,0)
   proc.stdin.write(a.tobytes())
   if fi%144==0:print('ENCODE',fi,'/',frames,'time',round(time.time()-tic,1),flush=True)
  proc.stdin.close();stat=proc.wait(timeout=120)
  if stat:raise RuntimeError('ffmpeg status '+str(stat)+' '+proc.stderr.read().decode()[-500:])
 except Exception:
  proc.kill();raise
 print('COMPLETE',out,os.stat(out).st_size,round(time.time()-tic,1),flush=True)
if __name__=='__main__':build()
